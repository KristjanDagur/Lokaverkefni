# Wolf > 2021-08-19 7:41am
https://universe.roboflow.com/eprte/wolf

Provided by a Roboflow user
License: Public Domain

